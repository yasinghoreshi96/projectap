﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;


namespace project_ap
{

  
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public projectDataContext prj = new projectDataContext();

        public Window2()
        {
            InitializeComponent();
        }

        //regex for name
        public bool rgname(string name)
        {

            string pattern = @"[\p{L} ]+$";
            Regex regex = new Regex(pattern);
            if (regex.IsMatch(name) == false)
            {
                return true;
            }
            return false;

        }
        //regex for name done

        //regex for password
        public bool rgxpass(string pass)
        {

            string pattern = @"([A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9]*";

            Regex regex = new Regex(pattern);
            if (regex.IsMatch(pass) == true)
            {
                if (pass.Contains("@") || pass.Contains("!") || pass.Contains("#") || pass.Contains("$") || pass.Contains("%") || pass.Contains("^") || pass.Contains("&") || pass.Contains("*") || pass.Contains("(") || pass.Contains(")") || pass.Contains("-") || pass.Contains("_") || pass.Contains("+") || pass.Contains("=") || pass.Contains("'") || pass.Contains(";") || pass.Contains(":") || pass.Contains(">") || pass.Contains("<") || pass.Contains(".") || pass.Contains(",") || pass.Contains("`") || pass.Contains("~"))
                {
                    return false;
                }
                else
                    return true;
            }
            else
            return true;
        }
        //regex for password done


        //regex for phone
        public bool checkphone(string ph)
        {
            bool value;
            
            if (Regex.IsMatch(ph, @"^\d+$"))
            {
                if (ph.Contains("00989"))
                {
                   value= false;
                }
                else if (ph.Contains("+9809"))
                {
                    value = false;
                }
                else if (ph.Contains("09"))
                {
                    value = false;
                }
                else if (ph[0] == '9')
                {
                    value = false;
                }
                else if (ph.Contains("+989"))
                {
                    value = false;
                }

                else
                    value = true;

            }
            else
                value = true;

            return value;


        }
        // regex for phone done



        //regex for email

        bool IsValidEmail(string email)
        {
            // Return true if strIn is in valid e-mail format.
            if (Regex.IsMatch(email, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"))
            {
                return false;

            }
            else return true;
        }
        //regex for email done

         //regex for nationalcode

        public bool ncodecheck(string ncode)
        {
            float n;
           int a, b, c;

            if (Regex.IsMatch(ncode, @"^\d+$"))
            {
                

                n = float.Parse(ncode);
                if (n > 999999999 && n < 10000000000)
                {
                    //
                    int j;
                    string[] str = new string[10];
                    for (j = 0; j < 10; j++)
                    {
                        str[j] = ncode[j].ToString();
                    }
                    //

                    a = int.Parse(str[9]);
                    b = (int.Parse(str[0]) * 10) + (int.Parse(str[1]) * 9) + (int.Parse(str[2]) * 8) + (int.Parse(str[3]) * 7) + (int.Parse(str[4]) * 6) + (int.Parse(str[5]) * 5) + (int.Parse(str[6]) * 4) + (int.Parse(str[7]) * 3) + (int.Parse(str[8]) * 2);
                    c = b % 11;
                    //
                    int s = a - 11;
                    if (s < 0)
                        s = -s;
                    //
                    if ((a == 0 && c == 0) || (a == 1 && c == 1) || (c > 1 && s == c))
                    {
                        return false;
                    }
                    else
                        return true;


                }
                else
                    return true;


            }
            else
            return true;

        }
        //regex for nationalcode done



        
        private void Button_Click(object sender, RoutedEventArgs e)
        {



            //

         
            

            //


            if (pass.Text != pass2.Text)
                MessageBox.Show("پسورد و تکرار ان متفاوت است");
            else if (rgname(name.Text))
                MessageBox.Show("فرمت اسم اشتباه است");
            else if (rgxpass(pass.Text))
                MessageBox.Show(" فرمت رمز اشتباه است باید شامل همه حروف و علایم باشد");
            else if (checkphone(phone.Text))
                MessageBox.Show(" فرمت شماره اشتباه است");
            else if (IsValidEmail(email.Text))
                MessageBox.Show(" فرمت ایمیل اشتباه است");
            else if (ncodecheck(nationalcode.Text))
                MessageBox.Show(" فرمت کد ملی اشتباه است");


            else
            { 
                prj.insertintomoshtari(nationalcode.Text, name.Text, adress.Text, phone.Text, email.Text, pass.Text, pass2.Text);

            MainWindow win = new MainWindow();
            win.Show();
            this.Hide();
                MessageBox.Show("ثبت نام انجام شد");
            }
        }

       

        private void Butexit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win3 = new MainWindow();
            this.Hide();
            win3.Show();
        }
    }


}



