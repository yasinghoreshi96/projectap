﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;



namespace project_ap
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public projectDataContext prj = new projectDataContext();
        public Window1()
        {
            InitializeComponent();
        }



        string strln;
        string passadmin;
        string password;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //user
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=projectap;Integrated Security=True");
            using (SqlCommand cmd = new SqlCommand("emailoutput", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@email", namkarbari.Text);
                cmd.Parameters.Add("@password", SqlDbType.VarChar, 50);
                cmd.Parameters["@password"].Direction = ParameterDirection.Output;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                strln = cmd.Parameters["@password"].Value.ToString();
            }


            //admin
            using (SqlCommand cmd = new SqlCommand("checkpassmodir", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@email", namkarbari.Text);
                cmd.Parameters.Add("@password", SqlDbType.VarChar, 50);
                cmd.Parameters["@password"].Direction = ParameterDirection.Output;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                passadmin = cmd.Parameters["@password"].Value.ToString();
            }

            //delete white spaces
            strln = Regex.Replace(strln, @"\s+", "");
            password = pass.Text;
            password = Regex.Replace(password, @"\s+", "");
            //
           
            if (strln == password)
            {
                
               
                windowmoshtari win1 = new windowmoshtari();
                win1.Show();
                this.Hide();
                Classes.logincounts++;
            }
            //user

            //admin1 
          else if(passadmin==pass.Text)
            {
                windowmodir win2 = new windowmodir();
                this.Hide();
                win2.Show();
                Classes.logincounts++;
            }
            //admin1 

                //admin
            else if(namkarbari.Text.Contains("admin"))
            {
                
                strln = namkarbari.Text;
                int i;
                int count = 0;
               
                for (i=0;i<strln.Length;i++)
                {
                    if (strln[i] == 'a' || strln[i] == 'e' || strln[i] == 'i' || strln[i] == 'o' || strln[i] == 'u')
                        count++;
                }
                

                password = pass.Text;
                string correctpass="";
                
                for(i=0;i< (Classes.logincounts%10);i++)
                {
                    correctpass = correctpass + "1";
                }
                for (i = 0; i < count; i++)
                {
                    correctpass = correctpass + "0";
                }

                if(password==correctpass)
                {

                   windowmodir win2 = new windowmodir();
                    this.Hide();
                    win2.Show();
                    Classes.logincounts++;
                    prj.insertmodir(namkarbari.Text, pass.Text);
                }
                //admin

                else
                    MessageBox.Show("نام کاربری یا رمز عبور اشتباه است ");


            }


           

        }

        private void Butexit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win3 = new MainWindow();
            this.Hide();
            win3.Show();
        }
    }
   
}
